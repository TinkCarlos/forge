from __future__ import annotations

from typing import Any

import jwt

from .errors import ConnectorIdentityError
from .models import AgentPrincipal, AgentRole


def verify_principal_token(
    token: str,
    *,
    public_key: str,
    issuer: str,
    audience: str,
    application: str,
    environment: str,
    key_id: str | None = None,
) -> AgentPrincipal:
    try:
        header = jwt.get_unverified_header(token)
        if (
            header.get("alg") != "RS256"
            or header.get("typ") != "JWT"
            or (key_id and header.get("kid") != key_id)
        ):
            raise ConnectorIdentityError("Unexpected principal token header")
        claims = jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            issuer=issuer,
            audience=audience,
            options={"require": ["sub", "iat", "exp", "jti"]},
        )
    except ConnectorIdentityError:
        raise
    except (jwt.PyJWTError, ValueError, TypeError) as exc:
        raise ConnectorIdentityError("Agent principal token is invalid") from exc

    claim_application = claims.get("application") or claims.get("azp")
    claim_environment = claims.get("environment")
    if claim_application != application or claim_environment != environment:
        raise ConnectorIdentityError("Agent principal target does not match this Connector")
    roles = _normalize_roles(claims.get("roles", []))
    scopes = _normalize_scopes(claims.get("scope", claims.get("scopes", [])))
    principal_type = claims.get("principal_type", "delegated_user")
    try:
        return AgentPrincipal(
            principal_type=principal_type,
            subject=claims["sub"],
            agent_user_id=claims.get("agent_user_id"),
            enterprise_user_id=claims.get("userid"),
            client_id=claims.get("client_id") or claims.get("azp"),
            source_system_id=claims.get("source_system_id"),
            username=claims.get("preferred_username"),
            display_name=claims.get("name"),
            application=application,
            environment=environment,
            roles=roles,
            scopes=scopes,
            issued_at=int(claims["iat"]),
            expires_at=int(claims["exp"]),
            token_id=claims.get("jti"),
            trace_id=claims.get("trace_id"),
        )
    except (TypeError, ValueError) as exc:
        raise ConnectorIdentityError("Agent principal claims are invalid") from exc


def _normalize_roles(value: Any) -> list[AgentRole]:
    if not isinstance(value, list):
        raise ConnectorIdentityError("Agent roles claim must be a list")
    roles: list[AgentRole] = []
    for item in value:
        if isinstance(item, str) and item.strip():
            roles.append(AgentRole(code=item.strip(), name=item.strip()))
        elif isinstance(item, dict):
            roles.append(AgentRole.model_validate(item))
        else:
            raise ConnectorIdentityError("Agent roles claim contains an invalid role")
    return roles


def _normalize_scopes(value: Any) -> list[str]:
    if isinstance(value, str):
        return sorted({item for item in value.split() if item})
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return sorted({item for item in value if item})
    raise ConnectorIdentityError("Agent scopes claim is invalid")
