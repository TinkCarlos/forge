from __future__ import annotations

import inspect
import json
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

from .errors import ConnectorIdentityError
from .models import AgentPrincipal

PrincipalVerifier = Callable[[str], AgentPrincipal | Awaitable[AgentPrincipal]]

RESERVED_IDENTITY_HEADERS = {
    b"x-agent-user-id",
    b"x-agent-enterprise-user-id",
    b"x-agent-subject",
    b"x-agent-roles",
    b"x-agent-scopes",
    b"x-agent-system-id",
    b"x-agent-admin",
    b"x-agent-user-assertion",
    b"x-forwarded-user",
}


class AgentConnectorMiddleware:
    def __init__(
        self,
        app,
        *,
        verifier: PrincipalVerifier,
        protected_paths: Iterable[str] = ("/",),
        excluded_paths: Iterable[str] = ("/health", "/ready", "/oidc/callback"),
    ) -> None:
        self.app = app
        self.verifier = verifier
        self.protected_paths = tuple(_clean_prefix(item) for item in protected_paths)
        self.excluded_paths = tuple(_clean_prefix(item) for item in excluded_paths)

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] not in {"http", "websocket"}:
            await self.app(scope, receive, send)
            return
        path = scope.get("path", "/")
        token = _principal_token(scope.get("headers", []))
        scope["headers"] = [
            (name, value)
            for name, value in scope.get("headers", [])
            if name.lower() not in RESERVED_IDENTITY_HEADERS
        ]
        if not self._is_protected(path):
            await self.app(scope, receive, send)
            return
        if not token:
            await _json_error(send, 401, "CONNECTOR_PRINCIPAL_INVALID", "Authentication required")
            return
        try:
            principal = self.verifier(token)
            if inspect.isawaitable(principal):
                principal = await principal
            if not isinstance(principal, AgentPrincipal):
                raise ConnectorIdentityError("Principal verifier returned an invalid value")
        except ConnectorIdentityError as exc:
            await _json_error(send, 401, exc.code, str(exc))
            return
        state = scope.setdefault("state", {})
        state["agent_principal"] = principal
        scope["headers"].extend(_principal_headers(principal))
        await self.app(scope, receive, send)

    def _is_protected(self, path: str) -> bool:
        if any(_matches(path, prefix) for prefix in self.excluded_paths):
            return False
        return any(_matches(path, prefix) for prefix in self.protected_paths)


def get_agent_principal(request: Any) -> AgentPrincipal:
    principal = getattr(getattr(request, "state", None), "agent_principal", None)
    if not isinstance(principal, AgentPrincipal):
        raise ConnectorIdentityError("Agent principal is not available on this request")
    return principal


def _clean_prefix(value: str) -> str:
    normalized = value.strip().rstrip("/") or "/"
    if not normalized.startswith("/") or "//" in normalized or "\\" in normalized:
        raise ValueError("Middleware paths must be clean absolute paths")
    return normalized


def _matches(path: str, prefix: str) -> bool:
    return prefix == "/" or path == prefix or path.startswith(prefix + "/")


def _bearer_token(headers: list[tuple[bytes, bytes]]) -> str | None:
    for name, value in headers:
        if name.lower() != b"authorization":
            continue
        decoded = value.decode("latin-1")
        scheme, _, token = decoded.partition(" ")
        if scheme.lower() == "bearer" and token.strip():
            return token.strip()
    return None


def _principal_token(headers: list[tuple[bytes, bytes]]) -> str | None:
    # Agent 网关使用签名断言承载委托用户，浏览器/API 可直接使用 Bearer Principal。
    for name, value in headers:
        if name.lower() == b"x-agent-user-assertion" and value.strip():
            return value.decode("latin-1").strip()
    return _bearer_token(headers)


def _principal_headers(principal: AgentPrincipal) -> list[tuple[bytes, bytes]]:
    values = {
        "x-agent-subject": principal.subject,
        "x-agent-user-id": principal.agent_user_id or "",
        "x-agent-enterprise-user-id": principal.enterprise_user_id or "",
        "x-agent-roles": json.dumps(
            [role.model_dump() for role in principal.roles],
            ensure_ascii=True,
            separators=(",", ":"),
        ),
        "x-agent-scopes": " ".join(principal.scopes),
        "x-agent-system-id": principal.source_system_id or "",
    }
    return [(name.encode("ascii"), value.encode("utf-8")) for name, value in values.items()]


async def _json_error(send, status: int, code: str, message: str) -> None:
    body = json.dumps(
        {"code": code, "message": message, "retryable": False}, separators=(",", ":")
    ).encode()
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode()),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})
