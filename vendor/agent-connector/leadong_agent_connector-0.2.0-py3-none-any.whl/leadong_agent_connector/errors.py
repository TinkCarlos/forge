class ConnectorError(Exception):
    code = "CONNECTOR_ERROR"


class ConnectorConfigError(ConnectorError):
    code = "CONNECTOR_CONFIG_INVALID"


class ConnectorConfigSignatureError(ConnectorConfigError):
    code = "CONNECTOR_CONFIG_SIGNATURE_INVALID"


class ConnectorConfigRollbackError(ConnectorConfigError):
    code = "CONNECTOR_CONFIG_VERSION_ROLLBACK"


class ConnectorEnvironmentMismatch(ConnectorConfigError):
    code = "CONNECTOR_ENVIRONMENT_MISMATCH"


class ConnectorIdentityError(ConnectorError):
    code = "CONNECTOR_PRINCIPAL_INVALID"


class ConnectorPolicyDenied(ConnectorError):
    code = "CONNECTOR_CALL_DENIED"


class ConnectorHardDenied(ConnectorPolicyDenied):
    code = "CONNECTOR_HARD_DENY"
