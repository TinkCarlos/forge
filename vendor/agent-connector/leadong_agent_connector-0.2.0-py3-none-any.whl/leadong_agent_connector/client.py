from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

import httpx

from .config import ConnectorConfigStore
from .models import (
    ConnectorEnrollmentRequest,
    ConnectorEnrollmentResponse,
    GatewayResponse,
    SignedConfigEnvelope,
)
from .policy import authorize_call

TokenProvider = Callable[[], Awaitable[str]]


class AgentConnectorEnrollmentClient:
    """Exchange a single-use enrollment token for Connector bootstrap data."""

    def __init__(
        self,
        *,
        agent_url: str,
        timeout_seconds: float = 15,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._client = httpx.AsyncClient(
            base_url=agent_url.rstrip("/"),
            timeout=timeout_seconds,
            transport=transport,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self.aclose()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def enroll(
        self, request: ConnectorEnrollmentRequest | dict[str, Any]
    ) -> ConnectorEnrollmentResponse:
        payload = (
            request
            if isinstance(request, ConnectorEnrollmentRequest)
            else ConnectorEnrollmentRequest.model_validate(request)
        )
        response = await self._client.post(
            "/api/v1/connectors:enroll",
            json=payload.model_dump(mode="json", by_alias=True),
        )
        response.raise_for_status()
        return ConnectorEnrollmentResponse.model_validate(response.json())


class AgentConnectorClient:
    def __init__(
        self,
        *,
        agent_url: str,
        connector_id: str,
        instance_id: str | None = None,
        token_provider: TokenProvider,
        config_store: ConnectorConfigStore,
        timeout_seconds: float = 15,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.connector_id = connector_id
        self.instance_id = instance_id
        self.token_provider = token_provider
        self.config_store = config_store
        self._client = httpx.AsyncClient(
            base_url=agent_url.rstrip("/"),
            timeout=timeout_seconds,
            transport=transport,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self.aclose()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {await self.token_provider()}"}

    async def refresh_config(self) -> bool:
        headers = await self._headers()
        if self.config_store.etag:
            headers["If-None-Match"] = self.config_store.etag
        if self.instance_id:
            headers["X-Connector-Instance-Id"] = self.instance_id
        response = await self._client.get(
            f"/api/v1/connectors/{self.connector_id}/config",
            headers=headers,
        )
        if response.status_code == 304:
            return False
        response.raise_for_status()
        return self.config_store.apply(SignedConfigEnvelope.model_validate(response.json()))

    async def heartbeat(
        self,
        *,
        instance_id: str,
        connector_version: str,
        protocol_version: str = "1.0",
        status: str = "healthy",
    ) -> None:
        response = await self._client.post(
            f"/api/v1/connectors/{self.connector_id}/heartbeat",
            headers=await self._headers(),
            json={
                "instanceId": instance_id,
                "connectorVersion": connector_version,
                "protocolVersion": protocol_version,
                "configVersion": self.config_store.version,
                "status": status,
            },
        )
        response.raise_for_status()

    async def emit_events(self, events: list[dict[str, Any]]) -> dict[str, int]:
        response = await self._client.post(
            f"/api/v1/connectors/{self.connector_id}/events:batch",
            headers=await self._headers(),
            json={"items": events},
        )
        response.raise_for_status()
        return response.json()

    async def call_system(
        self,
        target_system_id: str,
        *,
        method: str,
        path: str,
        query: dict[str, Any] | None = None,
        body: Any = None,
        headers: dict[str, str] | None = None,
        capability_code: str | None = None,
        timeout_seconds: float = 30,
    ) -> GatewayResponse:
        if self.config_store.current is None:
            raise RuntimeError("Connector configuration is not loaded")
        authorize_call(
            self.config_store.current,
            direction="outbound",
            peer_system_id=target_system_id,
            method=method,
            path=path,
            capability=capability_code,
        )
        response = await self._client.post(
            f"/api/v1/integrations/systems/{target_system_id}:request",
            headers=await self._headers(),
            json={
                "method": method.upper(),
                "path": path,
                "query": query or {},
                "headers": headers or {},
                "body_type": "json",
                "body": body,
                "timeout_seconds": timeout_seconds,
                "capability_code": capability_code,
            },
        )
        response.raise_for_status()
        return GatewayResponse.model_validate(response.json())
