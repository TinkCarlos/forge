from __future__ import annotations

import re
from urllib.parse import unquote

from .errors import ConnectorHardDenied, ConnectorPolicyDenied
from .models import AgentPrincipal, CallPolicy, ConnectorConfig
from .principal import verify_principal_token

HARD_DENY_PREFIXES = (
    "/api/credentials",
    "/api/keys",
    "/api/secrets",
    "/api/tokens",
)


def normalize_path(path: str) -> str:
    encoded = path.strip()
    try:
        for _ in range(2):
            if re.search(r"%(?![0-9A-Fa-f]{2})", encoded):
                raise ValueError("Malformed percent encoding")
            encoded = unquote(encoded, errors="strict")
        decoded = encoded
    except (UnicodeDecodeError, ValueError) as exc:
        raise ConnectorHardDenied("Unsafe request path encoding") from exc
    if (
        not decoded.startswith("/")
        or "?" in decoded
        or "#" in decoded
        or "\\" in decoded
        or "//" in decoded
        or any(part in {".", ".."} for part in decoded.split("/"))
    ):
        raise ConnectorHardDenied("Unsafe request path")
    return decoded.rstrip("/") or "/"


def authorize_call(
    config: ConnectorConfig,
    *,
    direction: str,
    peer_system_id: str,
    method: str,
    path: str,
    capability: str | None = None,
) -> CallPolicy:
    normalized_path = normalize_path(path)
    normalized_method = method.upper()
    if any(
        normalized_path == prefix or normalized_path.startswith(prefix + "/")
        for prefix in HARD_DENY_PREFIXES
    ):
        raise ConnectorHardDenied("Request path is blocked by the Connector hard deny list")
    policies = config.calls.get(direction)
    if policies is None:
        raise ConnectorPolicyDenied("Unknown Connector call direction")
    policy = next((item for item in policies if item.peer_system_id == peer_system_id), None)
    if policy is None or policy.mode == "deny":
        raise ConnectorPolicyDenied("No active Connector call policy")
    if (
        normalized_method not in policy.allowed_methods
        or normalized_method in policy.denied_methods
    ):
        raise ConnectorPolicyDenied("HTTP method is not allowed")
    if not any(_matches_prefix(normalized_path, prefix) for prefix in policy.safe_path_prefixes):
        raise ConnectorPolicyDenied("Request path is outside the safe prefixes")
    if any(_matches_pattern(normalized_path, pattern) for pattern in policy.denied_path_patterns):
        raise ConnectorPolicyDenied("Request path is denied")
    if policy.mode == "read_only_open" and normalized_method not in {"GET", "HEAD", "OPTIONS"}:
        raise ConnectorPolicyDenied("Read-only policy rejected a write request")
    if policy.mode == "allowlist" and (
        not capability or capability not in policy.allowed_capabilities
    ):
        raise ConnectorPolicyDenied("Capability is not allowlisted")
    return policy


def verify_and_authorize_inbound(
    config: ConnectorConfig,
    token: str,
    *,
    method: str,
    path: str,
    public_key: str,
    issuer: str,
    audience: str,
    application: str,
    environment: str,
    key_id: str | None = None,
    capability: str | None = None,
    default_peer_system_id: str | None = "platform",
) -> tuple[AgentPrincipal, CallPolicy, str]:
    principal = verify_principal_token(
        token,
        public_key=public_key,
        issuer=issuer,
        audience=audience,
        application=application,
        environment=environment,
        key_id=key_id,
    )
    peer_system_id = principal.source_system_id or default_peer_system_id
    if not peer_system_id:
        raise ConnectorPolicyDenied("Verified principal has no source system")
    policy = authorize_call(
        config,
        direction="inbound",
        peer_system_id=peer_system_id,
        method=method,
        path=path,
        capability=capability,
    )
    return principal, policy, peer_system_id


def _matches_prefix(path: str, prefix: str) -> bool:
    normalized = prefix.rstrip("/") or "/"
    return normalized == "/" or path == normalized or path.startswith(normalized + "/")


def _matches_pattern(path: str, pattern: str) -> bool:
    normalized = pattern.removesuffix("/**").rstrip("/") or "/"
    return path == normalized or path.startswith(normalized + "/")
