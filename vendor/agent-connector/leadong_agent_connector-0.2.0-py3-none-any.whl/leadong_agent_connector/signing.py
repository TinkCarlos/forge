from __future__ import annotations

import hashlib
import json
from typing import Any

import jwt

from .errors import ConnectorConfigSignatureError


def canonical_payload(payload: dict[str, Any]) -> bytes:
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def payload_hash(payload: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_payload(payload)).hexdigest()


def verify_signed_payload(
    payload: dict[str, Any],
    signature: str,
    *,
    public_key: str,
    key_id: str,
) -> None:
    try:
        header = jwt.get_unverified_header(signature)
        if (
            header.get("alg") != "RS256"
            or header.get("kid") != key_id
            or header.get("typ") != "connector-config+jws"
        ):
            raise ConnectorConfigSignatureError("Unexpected Connector signature header")
        decoded = jwt.decode(
            signature,
            public_key,
            algorithms=["RS256"],
            options={"verify_aud": False},
        )
    except ConnectorConfigSignatureError:
        raise
    except (jwt.PyJWTError, ValueError, TypeError) as exc:
        raise ConnectorConfigSignatureError("Connector configuration signature is invalid") from exc
    if canonical_payload(decoded) != canonical_payload(payload):
        raise ConnectorConfigSignatureError("Signed configuration payload does not match envelope")
