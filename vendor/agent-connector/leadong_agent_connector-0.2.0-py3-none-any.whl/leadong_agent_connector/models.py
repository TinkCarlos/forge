from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel


class ContractModel(BaseModel):
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class AgentRole(ContractModel):
    code: str
    name: str


class AgentPrincipal(ContractModel):
    schema_version: str = "1.0"
    principal_type: Literal["user", "service", "delegated_user"]
    subject: str
    agent_user_id: str | None = None
    enterprise_user_id: str | None = None
    client_id: str | None = None
    source_system_id: str | None = None
    username: str | None = None
    display_name: str | None = None
    application: str
    environment: Literal["test", "staging", "prod"]
    roles: list[AgentRole] = Field(default_factory=list)
    scopes: list[str] = Field(default_factory=list)
    issued_at: int
    expires_at: int
    token_id: str | None = None
    trace_id: str | None = None

    def has_role(self, *codes: str) -> bool:
        expected = set(codes)
        return any(role.code in expected for role in self.roles)

    def has_scope(self, scope: str) -> bool:
        return scope in self.scopes


class CallPolicy(ContractModel):
    grant_id: str
    peer_system_id: str
    mode: Literal["deny", "allowlist", "denylist", "read_only_open"]
    safe_path_prefixes: list[str]
    allowed_methods: list[str]
    denied_methods: list[str]
    denied_path_patterns: list[str]
    allowed_capabilities: list[str] = Field(default_factory=list)
    data_scope_type: str = "all"
    data_scope: dict[str, Any] | None = None
    rate_limit: int = 0


class ConnectorSystem(ContractModel):
    id: str
    code: str
    environment: Literal["test", "staging", "prod"]
    status: Literal["active", "suspended", "revoked"]


class ConnectorConfig(ContractModel):
    schema_version: str
    config_version: int
    system: ConnectorSystem
    trust: dict[str, Any]
    sso: dict[str, Any]
    roles: dict[str, Any]
    calls: dict[str, list[CallPolicy]]
    runtime: dict[str, Any]
    issued_at: datetime
    expires_at: datetime | None = None


class SignedConfigEnvelope(ContractModel):
    version: int
    payload: ConnectorConfig
    signature: str
    key_id: str
    payload_hash: str
    algorithm: Literal["RS256"]
    verification_key: str


class ConnectorInstanceDescriptor(ContractModel):
    instance_id: str = Field(min_length=8, max_length=128)
    version: str = Field(min_length=1, max_length=64)
    build: str | None = Field(default=None, max_length=128)


class ConnectorEnrollmentRequest(ContractModel):
    kind: Literal["enrollment_request"] = "enrollment_request"
    token: str = Field(min_length=32, max_length=2048)
    connector_type: Literal["node", "python", "sidecar"]
    protocol_version: str = Field(pattern=r"^1\.[0-9]+$")
    public_key: str = Field(min_length=64, max_length=8192)
    instance: ConnectorInstanceDescriptor
    capabilities: list[
        Literal["sso", "roles", "inbound", "outbound", "audit", "dynamic_config"]
    ] = Field(default_factory=list)


class ConnectorCredential(ContractModel):
    client_id: str
    authentication_mode: Literal["client_secret", "private_key_jwt", "workload_identity"]
    credential_version: int = Field(ge=1)
    client_secret: str | None = None


class ConnectorEnrollmentResponse(ContractModel):
    kind: Literal["enrollment_response"] = "enrollment_response"
    connector_id: str
    gateway_system_id: str
    environment: Literal["test", "staging", "prod"]
    credential: ConnectorCredential
    config: SignedConfigEnvelope


class GatewayResponse(ContractModel):
    request_id: str
    status_code: int
    content_type: str | None
    headers: dict[str, str]
    body: Any
    duration_ms: int
    truncated: bool
