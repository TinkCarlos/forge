from __future__ import annotations

import base64
import hashlib
import secrets
from dataclasses import dataclass
from urllib.parse import urlencode

import httpx


@dataclass(frozen=True, slots=True)
class OidcAuthorizationRequest:
    url: str
    state: str
    nonce: str
    code_verifier: str
    original_url: str


class OidcLoginManager:
    def __init__(
        self,
        *,
        authorization_endpoint: str,
        token_endpoint: str,
        client_id: str,
        client_secret: str | None = None,
        timeout_seconds: float = 10,
    ) -> None:
        self.authorization_endpoint = authorization_endpoint
        self.token_endpoint = token_endpoint
        self.client_id = client_id
        self.client_secret = client_secret
        self.timeout_seconds = timeout_seconds

    def create_authorization_request(
        self, *, redirect_uri: str, original_url: str = "/"
    ) -> OidcAuthorizationRequest:
        state = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
            .rstrip(b"=")
            .decode()
        )
        query = urlencode(
            {
                "response_type": "code",
                "client_id": self.client_id,
                "redirect_uri": redirect_uri,
                "scope": "openid profile email",
                "state": state,
                "nonce": nonce,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
            }
        )
        return OidcAuthorizationRequest(
            url=f"{self.authorization_endpoint}?{query}",
            state=state,
            nonce=nonce,
            code_verifier=verifier,
            original_url=original_url if original_url.startswith("/") else "/",
        )

    async def exchange_code(
        self,
        *,
        code: str,
        redirect_uri: str,
        code_verifier: str,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> dict:
        data = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "code": code,
            "redirect_uri": redirect_uri,
            "code_verifier": code_verifier,
        }
        if self.client_secret:
            data["client_secret"] = self.client_secret
        async with httpx.AsyncClient(timeout=self.timeout_seconds, transport=transport) as client:
            response = await client.post(self.token_endpoint, data=data)
            response.raise_for_status()
            return response.json()
