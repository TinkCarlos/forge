from __future__ import annotations

import json
import os
from datetime import UTC, datetime
from pathlib import Path

from .errors import (
    ConnectorConfigError,
    ConnectorConfigRollbackError,
    ConnectorEnvironmentMismatch,
)
from .models import ConnectorConfig, SignedConfigEnvelope
from .signing import payload_hash, verify_signed_payload


class ConnectorConfigStore:
    def __init__(
        self,
        *,
        expected_system_id: str,
        expected_environment: str,
        trusted_verification_key: str,
        cache_path: str | Path | None = None,
        trusted_key_id: str | None = None,
    ) -> None:
        self.expected_system_id = expected_system_id
        self.expected_environment = expected_environment
        self.cache_path = Path(cache_path) if cache_path else None
        self.trusted_verification_key = trusted_verification_key
        self.trusted_key_id = trusted_key_id
        self._envelope: SignedConfigEnvelope | None = None

    @property
    def current(self) -> ConnectorConfig | None:
        return self._envelope.payload if self._envelope else None

    @property
    def version(self) -> int:
        return self._envelope.version if self._envelope else 0

    @property
    def etag(self) -> str | None:
        return f'"{self._envelope.payload_hash}"' if self._envelope else None

    def apply(self, envelope: SignedConfigEnvelope | dict, *, allow_same: bool = True) -> bool:
        candidate = (
            envelope
            if isinstance(envelope, SignedConfigEnvelope)
            else SignedConfigEnvelope.model_validate(envelope)
        )
        payload = candidate.payload.model_dump(mode="json", by_alias=True)
        if candidate.algorithm != "RS256":
            raise ConnectorConfigError("Unsupported Connector configuration algorithm")
        verification_key = self.trusted_verification_key
        key_id = self.trusted_key_id or candidate.key_id
        if self.trusted_key_id and candidate.key_id != self.trusted_key_id:
            raise ConnectorConfigError("Connector signing key id is not trusted")
        verify_signed_payload(
            payload,
            candidate.signature,
            public_key=verification_key,
            key_id=key_id,
        )
        if payload_hash(payload) != candidate.payload_hash:
            raise ConnectorConfigError("Connector configuration hash does not match payload")
        if candidate.version != candidate.payload.config_version:
            raise ConnectorConfigError("Envelope and payload versions do not match")
        if candidate.payload.system.id != self.expected_system_id:
            raise ConnectorConfigError("Connector configuration belongs to another system")
        if candidate.payload.system.environment != self.expected_environment:
            raise ConnectorEnvironmentMismatch(
                "Connector configuration belongs to another environment"
            )
        if candidate.payload.system.status != "active":
            raise ConnectorConfigError("Connector system is not active")
        if candidate.payload.expires_at and candidate.payload.expires_at <= datetime.now(UTC):
            raise ConnectorConfigError("Connector configuration has expired")
        if candidate.version < self.version:
            raise ConnectorConfigRollbackError("Connector configuration version moved backwards")
        if candidate.version == self.version:
            if (
                allow_same
                and self._envelope
                and candidate.payload_hash == self._envelope.payload_hash
            ):
                return False
            raise ConnectorConfigRollbackError("Connector configuration version was reused")
        self._envelope = candidate
        self._write_cache(candidate)
        return True

    def load_cache(self) -> bool:
        if not self.cache_path or not self.cache_path.exists():
            return False
        self.apply(json.loads(self.cache_path.read_text(encoding="utf-8")))
        return True

    def _write_cache(self, envelope: SignedConfigEnvelope) -> None:
        if not self.cache_path:
            return
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.cache_path.with_suffix(self.cache_path.suffix + ".tmp")
        temporary.write_text(
            envelope.model_dump_json(by_alias=True),
            encoding="utf-8",
        )
        os.replace(temporary, self.cache_path)
