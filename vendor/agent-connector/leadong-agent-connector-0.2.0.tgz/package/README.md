# @leadong/agent-connector

Agent Connector 的 Node.js SDK（Node 20+，无运行时第三方依赖）。当前只在 Agent 仓库中开发，
尚未发布到 npm，也没有安装到 TermOps、KeywordAuto 等第三方项目。

## 首次注册

```bash
npx agent-connector enroll \
  --agent=https://autodeliver.leadong.com \
  --token=<Agent-Portal-生成的一次性接入码>
```

命令会生成 Connector 实例 RSA 密钥并把注册结果以 `0600` 权限写入
`.agent-connector/state.json`。注册响应中的 Agent 配置验签公钥必须固定保存，后续配置刷新
不能改信网络响应里携带的公钥。

## Express / NestJS

`createAgentConnectorMiddleware` 是标准 Express 中间件；NestJS 使用 Express adapter 时可在
`main.ts` 中调用 `app.use(middleware)`。它会删除请求自报的 `X-Agent-*` 身份头，仅在 Agent
签名 Principal 验证成功后重新注入可信身份，并将规范化身份放到
`request.agentPrincipal`。

```js
import {
  ConnectorConfigStore,
  createAgentConnectorMiddleware,
  verifyAndAuthorizeInbound,
  verifyPrincipalToken,
} from "@leadong/agent-connector"

const store = new ConnectorConfigStore({
  expectedSystemId: process.env.AGENT_SYSTEM_ID,
  expectedEnvironment: "test",
  trustedVerificationKey: process.env.AGENT_CONFIG_PUBLIC_KEY,
  trustedKeyId: process.env.AGENT_CONFIG_KEY_ID,
  cachePath: ".agent-connector/config.json",
})

app.use(createAgentConnectorMiddleware({
  verify: (token) => verifyPrincipalToken(token, principalVerificationOptions),
}))
```

需要同时完成身份和入站调用校验的框架适配层可调用：

```js
const {principal, policy, peerSystemId} = verifyAndAuthorizeInbound(
  store.current,
  principalToken,
  {method: req.method, path: req.path, ...principalVerificationOptions},
)
```

它先验签并校验
Principal 的目标系统，再使用签名后的 `sourceSystemId`（缺省为可信 Agent 平台）执行
`inbound` 策略，返回 `{ principal, policy, peerSystemId }`。原有
`verifyPrincipalToken` 与 `authorizeCall` 继续可用。

跨系统调用统一走 `AgentConnectorClient.callSystem()`；SDK 会先按已验签配置执行本地策略，
Agent 网关再做权威校验和审计。业务代码不保存对方系统密钥，也不能伪造角色或 Scope。

诊断命令从 `AGENT_ACCESS_TOKEN` 环境变量读取短期令牌，不接受命令行令牌参数，避免令牌进入
Shell 历史和进程列表。
