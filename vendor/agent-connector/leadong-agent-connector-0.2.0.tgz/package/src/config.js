import { mkdir, readFile, rename, writeFile } from "node:fs/promises"
import { dirname } from "node:path"

import {
  ConnectorConfigError,
  ConnectorConfigRollbackError,
  ConnectorEnvironmentMismatch,
} from "./errors.js"
import { payloadHash, verifySignedConfig } from "./signing.js"


export class ConnectorConfigStore {
  #envelope = null

  constructor({
    expectedSystemId,
    expectedEnvironment,
    trustedVerificationKey,
    trustedKeyId = null,
    cachePath = null,
  }) {
    if (!trustedVerificationKey) throw new TypeError("trustedVerificationKey is required")
    this.expectedSystemId = expectedSystemId
    this.expectedEnvironment = expectedEnvironment
    this.trustedVerificationKey = trustedVerificationKey
    this.trustedKeyId = trustedKeyId
    this.cachePath = cachePath
  }

  get current() { return this.#envelope?.payload ?? null }
  get version() { return this.#envelope?.version ?? 0 }
  get etag() { return this.#envelope ? `"${this.#envelope.payloadHash}"` : null }

  async apply(envelope, {allowSame = true} = {}) {
    validateEnvelope(envelope)
    if (envelope.algorithm !== "RS256") {
      throw new ConnectorConfigError("Unsupported Connector configuration algorithm")
    }
    if (this.trustedKeyId && envelope.keyId !== this.trustedKeyId) {
      throw new ConnectorConfigError("Connector signing key id is not trusted")
    }
    verifySignedConfig(envelope.payload, envelope.signature, {
      publicKey: this.trustedVerificationKey,
      keyId: this.trustedKeyId ?? envelope.keyId,
    })
    if (payloadHash(envelope.payload) !== envelope.payloadHash) {
      throw new ConnectorConfigError("Connector configuration hash does not match payload")
    }
    if (envelope.version !== envelope.payload.configVersion) {
      throw new ConnectorConfigError("Envelope and payload versions do not match")
    }
    if (envelope.payload.system.id !== this.expectedSystemId) {
      throw new ConnectorConfigError("Connector configuration belongs to another system")
    }
    if (envelope.payload.system.environment !== this.expectedEnvironment) {
      throw new ConnectorEnvironmentMismatch("Connector configuration belongs to another environment")
    }
    if (envelope.payload.system.status !== "active") {
      throw new ConnectorConfigError("Connector system is not active")
    }
    if (envelope.payload.expiresAt && Date.parse(envelope.payload.expiresAt) <= Date.now()) {
      throw new ConnectorConfigError("Connector configuration has expired")
    }
    if (envelope.version < this.version) {
      throw new ConnectorConfigRollbackError("Connector configuration version moved backwards")
    }
    if (envelope.version === this.version) {
      if (allowSame && this.#envelope?.payloadHash === envelope.payloadHash) return false
      throw new ConnectorConfigRollbackError("Connector configuration version was reused")
    }
    this.#envelope = structuredClone(envelope)
    await this.#writeCache()
    return true
  }

  async loadCache() {
    if (!this.cachePath) return false
    try {
      return await this.apply(JSON.parse(await readFile(this.cachePath, "utf8")))
    } catch (error) {
      if (error?.code === "ENOENT") return false
      throw error
    }
  }

  async #writeCache() {
    if (!this.cachePath) return
    await mkdir(dirname(this.cachePath), {recursive: true})
    const temporary = `${this.cachePath}.tmp`
    await writeFile(temporary, JSON.stringify(this.#envelope), {encoding: "utf8", mode: 0o600})
    await rename(temporary, this.cachePath)
  }
}

function validateEnvelope(envelope) {
  if (!envelope || typeof envelope !== "object" || !Number.isInteger(envelope.version) || envelope.version < 1) {
    throw new ConnectorConfigError("Connector configuration envelope is invalid")
  }
  if (!envelope.payload || !envelope.signature || !envelope.keyId || !envelope.payloadHash) {
    throw new ConnectorConfigError("Connector configuration envelope is incomplete")
  }
  const issuedAt = Date.parse(envelope.payload.issuedAt)
  const expiresAt = envelope.payload.expiresAt ? Date.parse(envelope.payload.expiresAt) : null
  if (
    envelope.payload.schemaVersion !== "1.0" || !Number.isFinite(issuedAt) ||
    (expiresAt !== null && !Number.isFinite(expiresAt)) ||
    !envelope.payload.system || !Array.isArray(envelope.payload.calls?.inbound) ||
    !Array.isArray(envelope.payload.calls?.outbound)
  ) throw new ConnectorConfigError("Connector configuration payload is invalid")
}
