export type Environment = "test" | "staging" | "prod"
export type PrincipalType = "user" | "service" | "delegated_user"
export interface AgentRole { code: string; name: string }
export interface AgentPrincipal {
  schemaVersion: "1.0"; principalType: PrincipalType; subject: string;
  agentUserId: string | null; enterpriseUserId: string | null; clientId: string | null;
  sourceSystemId: string | null;
  username: string | null; displayName: string | null; application: string;
  environment: Environment; roles: AgentRole[]; scopes: string[]; issuedAt: number;
  expiresAt: number; tokenId: string; traceId: string | null;
}
export interface SignedConfigEnvelope {
  version: number; payload: ConnectorConfig; signature: string; keyId: string;
  payloadHash: string; algorithm: "RS256"; verificationKey: string;
}
export interface ConnectorConfig {
  schemaVersion: "1.0"; configVersion: number;
  system: {id: string; code: string; environment: Environment; status: string};
  trust: {principalIssuer: string; principalAudience: string; principalKeyId: string;
    principalVerificationKey: string};
  sso: Record<string, unknown>; roles: Record<string, unknown>;
  calls: {inbound: CallPolicy[]; outbound: CallPolicy[]};
  runtime: Record<string, unknown>; issuedAt: string; expiresAt: string | null;
}
export interface CallPolicy {
  grantId: string; peerSystemId: string;
  mode: "deny" | "allowlist" | "denylist" | "read_only_open";
  safePathPrefixes: string[]; allowedMethods: string[]; deniedMethods: string[];
  deniedPathPatterns: string[]; allowedCapabilities: string[];
}
export interface InboundAuthorization {
  principal: AgentPrincipal; policy: CallPolicy; peerSystemId: string;
}
export class ConnectorError extends Error { code: string }
export class ConnectorConfigError extends ConnectorError {}
export class ConnectorConfigRollbackError extends ConnectorConfigError {}
export class ConnectorConfigSignatureError extends ConnectorConfigError {}
export class ConnectorEnvironmentMismatch extends ConnectorConfigError {}
export class ConnectorIdentityError extends ConnectorError {}
export class ConnectorPolicyDenied extends ConnectorError {}
export class ConnectorHardDenied extends ConnectorPolicyDenied {}
export class ConnectorConfigStore {
  constructor(options: {expectedSystemId: string; expectedEnvironment: Environment;
    trustedVerificationKey: string; trustedKeyId?: string | null; cachePath?: string | null});
  readonly current: ConnectorConfig | null; readonly version: number; readonly etag: string | null;
  apply(envelope: SignedConfigEnvelope, options?: {allowSame?: boolean}): Promise<boolean>;
  loadCache(): Promise<boolean>;
}
export class AgentConnectorClient {
  constructor(options: {agentUrl: string; connectorId: string; instanceId?: string | null;
    tokenProvider: () => Promise<string>;
    configStore: ConnectorConfigStore; fetchImpl?: typeof fetch});
  refreshConfig(): Promise<boolean>;
  heartbeat(input: {instanceId: string; connectorVersion: string; protocolVersion?: string;
    status?: "healthy" | "degraded" | "unhealthy"}): Promise<void>;
  emitEvents(events: Record<string, unknown>[]): Promise<{accepted: number; replayed: number}>;
  callSystem(targetSystemId: string, input: {method: string; path: string;
    query?: Record<string, unknown>; body?: unknown; headers?: Record<string, string>;
    capabilityCode?: string | null; timeoutSeconds?: number}): Promise<Record<string, unknown>>;
}
export function enrollConnector(input: Record<string, unknown>): Promise<Record<string, unknown>>
export function verifyPrincipalToken(token: string, options: Record<string, unknown>): AgentPrincipal
export function createAgentConnectorMiddleware(options: Record<string, unknown>): Function
export function authorizeCall(config: ConnectorConfig, request: Record<string, unknown>): CallPolicy
export function verifyAndAuthorizeInbound(
  config: ConnectorConfig,
  token: string,
  options: {
    method: string; path: string; capability?: string | null;
    defaultPeerSystemId?: string | null;
    publicKey: string; issuer: string; audience: string; application: string;
    environment: Environment; keyId?: string | null; now?: number;
  },
): InboundAuthorization
export function normalizePath(path: string): string
export const HARD_DENY_PREFIXES: readonly string[]
export function createOidcAuthorizationRequest(options: Record<string, string>): Record<string, string>
export function exchangeOidcCode(options: Record<string, unknown>): Promise<Record<string, unknown>>
export function canonicalJson(value: unknown): string
export function payloadHash(payload: unknown): string
export function verifySignedConfig(payload: unknown, signature: string, options: Record<string, string>): void
