import { createHash, randomBytes } from "node:crypto"


export function createOidcAuthorizationRequest({authorizationEndpoint, clientId, redirectUri, originalUrl = "/"}) {
  const state = randomBytes(32).toString("base64url")
  const nonce = randomBytes(32).toString("base64url")
  const codeVerifier = randomBytes(64).toString("base64url")
  const codeChallenge = createHash("sha256").update(codeVerifier).digest("base64url")
  const url = new URL(authorizationEndpoint)
  url.search = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: "openid profile email",
    state,
    nonce,
    code_challenge: codeChallenge,
    code_challenge_method: "S256",
  })
  return {url: url.toString(), state, nonce, codeVerifier, originalUrl: safeReturnUrl(originalUrl)}
}

export async function exchangeOidcCode({
  tokenEndpoint, clientId, clientSecret = null, code, redirectUri, codeVerifier,
  fetchImpl = globalThis.fetch,
}) {
  const body = new URLSearchParams({
    grant_type: "authorization_code", client_id: clientId, code,
    redirect_uri: redirectUri, code_verifier: codeVerifier,
  })
  if (clientSecret) body.set("client_secret", clientSecret)
  const response = await fetchImpl(tokenEndpoint, {method: "POST", body})
  if (!response.ok) throw new Error(`OIDC token exchange failed (${response.status})`)
  return response.json()
}

function safeReturnUrl(value) {
  const text = String(value)
  return text.startsWith("/") && !text.startsWith("//") && !text.includes("\\") ? text : "/"
}
