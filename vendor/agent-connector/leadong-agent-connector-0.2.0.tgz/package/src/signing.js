import { createHash, verify } from "node:crypto"

import { ConnectorConfigSignatureError, ConnectorIdentityError } from "./errors.js"


export function canonicalJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value)
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`
}

export function payloadHash(payload) {
  return createHash("sha256").update(canonicalJson(payload)).digest("hex")
}

function decodePart(value) {
  try {
    return Buffer.from(value, "base64url")
  } catch (error) {
    throw new ConnectorConfigSignatureError("Connector signature is not base64url encoded", {cause: error})
  }
}

export function verifyCompactJws(token, publicKey, {keyId, type, identity = false} = {}) {
  const ErrorType = identity ? ConnectorIdentityError : ConnectorConfigSignatureError
  const parts = String(token).split(".")
  if (parts.length !== 3) throw new ErrorType("Signed token is malformed")
  let header
  let payload
  try {
    header = JSON.parse(decodePart(parts[0]).toString("utf8"))
    payload = JSON.parse(decodePart(parts[1]).toString("utf8"))
  } catch (error) {
    if (error instanceof ErrorType) throw error
    throw new ErrorType("Signed token JSON is invalid")
  }
  if (header.alg !== "RS256" || (keyId && header.kid !== keyId) || (type && header.typ !== type)) {
    throw new ErrorType("Unexpected signed token header")
  }
  const valid = verify(
    "RSA-SHA256",
    Buffer.from(`${parts[0]}.${parts[1]}`),
    publicKey,
    decodePart(parts[2]),
  )
  if (!valid) throw new ErrorType("Signed token signature is invalid")
  return payload
}

export function verifySignedConfig(payload, signature, {publicKey, keyId}) {
  const decoded = verifyCompactJws(signature, publicKey, {
    keyId,
    type: "connector-config+jws",
  })
  if (canonicalJson(decoded) !== canonicalJson(payload)) {
    throw new ConnectorConfigSignatureError("Signed configuration does not match envelope")
  }
}
