import { ConnectorHardDenied, ConnectorPolicyDenied } from "./errors.js"
import { verifyPrincipalToken } from "./principal.js"


export const HARD_DENY_PREFIXES = Object.freeze([
  "/api/credentials",
  "/api/keys",
  "/api/secrets",
  "/api/tokens",
])

export function normalizePath(path) {
  let decoded
  try {
    decoded = decodeURIComponent(decodeURIComponent(String(path).trim()))
  } catch {
    throw new ConnectorHardDenied("Unsafe request path encoding")
  }
  if (
    !decoded.startsWith("/") || decoded.includes("?") || decoded.includes("#") ||
    decoded.includes("\\") || decoded.includes("//") ||
    decoded.split("/").some((part) => part === "." || part === "..")
  ) throw new ConnectorHardDenied("Unsafe request path")
  return decoded.replace(/\/$/, "") || "/"
}

export function authorizeCall(config, {direction, peerSystemId, method, path, capability = null}) {
  const normalizedPath = normalizePath(path)
  const normalizedMethod = String(method).toUpperCase()
  if (HARD_DENY_PREFIXES.some((prefix) => matchesPrefix(normalizedPath, prefix))) {
    throw new ConnectorHardDenied("Request path is blocked by the Connector hard deny list")
  }
  const policies = config?.calls?.[direction]
  if (!Array.isArray(policies)) throw new ConnectorPolicyDenied("Unknown call direction")
  const policy = policies.find((item) => item.peerSystemId === peerSystemId)
  if (!policy || policy.mode === "deny") throw new ConnectorPolicyDenied("No active call policy")
  if (!policy.allowedMethods.includes(normalizedMethod) || policy.deniedMethods.includes(normalizedMethod)) {
    throw new ConnectorPolicyDenied("HTTP method is not allowed")
  }
  if (!policy.safePathPrefixes.some((prefix) => matchesPrefix(normalizedPath, prefix))) {
    throw new ConnectorPolicyDenied("Request path is outside the safe prefixes")
  }
  if (policy.deniedPathPatterns.some((pattern) => matchesPattern(normalizedPath, pattern))) {
    throw new ConnectorPolicyDenied("Request path is denied")
  }
  if (policy.mode === "read_only_open" && !["GET", "HEAD", "OPTIONS"].includes(normalizedMethod)) {
    throw new ConnectorPolicyDenied("Read-only policy rejected a write request")
  }
  if (policy.mode === "allowlist" && (!capability || !policy.allowedCapabilities.includes(capability))) {
    throw new ConnectorPolicyDenied("Capability is not allowlisted")
  }
  return policy
}

export function verifyAndAuthorizeInbound(config, token, {
  method,
  path,
  capability = null,
  defaultPeerSystemId = "platform",
  ...verificationOptions
}) {
  const principal = verifyPrincipalToken(token, verificationOptions)
  const peerSystemId = principal.sourceSystemId ?? defaultPeerSystemId
  if (!peerSystemId) {
    throw new ConnectorPolicyDenied("Verified principal has no source system")
  }
  const policy = authorizeCall(config, {
    direction: "inbound",
    peerSystemId,
    method,
    path,
    capability,
  })
  return Object.freeze({principal, policy, peerSystemId})
}

function matchesPrefix(path, prefix) {
  const normalized = prefix.replace(/\/$/, "") || "/"
  return normalized === "/" || path === normalized || path.startsWith(`${normalized}/`)
}

function matchesPattern(path, pattern) {
  return matchesPrefix(path, pattern.replace(/\/\*\*$/, ""))
}
