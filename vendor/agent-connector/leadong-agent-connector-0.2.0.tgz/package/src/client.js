import { authorizeCall } from "./policy.js"


export class AgentConnectorClient {
  constructor({agentUrl, connectorId, instanceId = null, tokenProvider, configStore, fetchImpl = globalThis.fetch}) {
    this.agentUrl = agentUrl.replace(/\/$/, "")
    this.connectorId = connectorId
    this.instanceId = instanceId
    this.tokenProvider = tokenProvider
    this.configStore = configStore
    this.fetch = fetchImpl
  }

  async refreshConfig() {
    const headers = await this.#headers()
    if (this.configStore.etag) headers["If-None-Match"] = this.configStore.etag
    if (this.instanceId) headers["X-Connector-Instance-Id"] = this.instanceId
    const response = await this.fetch(`${this.agentUrl}/api/v1/connectors/${this.connectorId}/config`, {headers})
    if (response.status === 304) return false
    await assertOk(response, "Connector configuration refresh")
    return this.configStore.apply(await response.json())
  }

  async heartbeat({instanceId, connectorVersion, protocolVersion = "1.0", status = "healthy"}) {
    const response = await this.fetch(`${this.agentUrl}/api/v1/connectors/${this.connectorId}/heartbeat`, {
      method: "POST",
      headers: await this.#headers(true),
      body: JSON.stringify({
        instanceId, connectorVersion, protocolVersion,
        configVersion: this.configStore.version, status,
      }),
    })
    await assertOk(response, "Connector heartbeat")
  }

  async emitEvents(events) {
    const response = await this.fetch(`${this.agentUrl}/api/v1/connectors/${this.connectorId}/events:batch`, {
      method: "POST", headers: await this.#headers(true), body: JSON.stringify({items: events}),
    })
    await assertOk(response, "Connector event delivery")
    return response.json()
  }

  async callSystem(targetSystemId, {
    method, path, query = {}, body = null, headers = {}, capabilityCode = null,
    timeoutSeconds = 30,
  }) {
    if (!this.configStore.current) throw new Error("Connector configuration is not loaded")
    authorizeCall(this.configStore.current, {
      direction: "outbound", peerSystemId: targetSystemId, method, path,
      capability: capabilityCode,
    })
    const response = await this.fetch(`${this.agentUrl}/api/v1/integrations/systems/${targetSystemId}:request`, {
      method: "POST",
      headers: await this.#headers(true),
      body: JSON.stringify({
        method: method.toUpperCase(), path, query, headers, body_type: "json", body,
        timeout_seconds: timeoutSeconds, capability_code: capabilityCode,
      }),
    })
    await assertOk(response, "Agent gateway call")
    return response.json()
  }

  async #headers(json = false) {
    const headers = {Authorization: `Bearer ${await this.tokenProvider()}`}
    if (json) headers["Content-Type"] = "application/json"
    return headers
  }
}

export async function enrollConnector({
  agentUrl, token, publicKey, instanceId, connectorVersion,
  connectorType = "node", protocolVersion = "1.0", build = null,
  capabilities = ["sso", "roles", "inbound", "outbound", "audit", "dynamic_config"],
  fetchImpl = globalThis.fetch,
}) {
  const response = await fetchImpl(`${agentUrl.replace(/\/$/, "")}/api/v1/connectors:enroll`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      kind: "enrollment_request", token, connectorType, protocolVersion, publicKey,
      instance: {instanceId, version: connectorVersion, build}, capabilities,
    }),
  })
  await assertOk(response, "Connector enrollment")
  return response.json()
}

async function assertOk(response, operation) {
  if (response.ok) return
  let detail = ""
  try {
    const payload = await response.json()
    detail = payload.message || payload.code || ""
  } catch {}
  throw new Error(`${operation} failed (${response.status})${detail ? `: ${detail}` : ""}`)
}
