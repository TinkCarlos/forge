export class ConnectorError extends Error {
  constructor(message, code = "CONNECTOR_ERROR") {
    super(message)
    this.name = new.target.name
    this.code = code
  }
}

export class ConnectorConfigError extends ConnectorError {
  constructor(message, code = "CONNECTOR_CONFIG_INVALID") {
    super(message, code)
  }
}

export class ConnectorConfigSignatureError extends ConnectorConfigError {
  constructor(message) {
    super(message, "CONNECTOR_CONFIG_SIGNATURE_INVALID")
  }
}

export class ConnectorConfigRollbackError extends ConnectorConfigError {
  constructor(message) {
    super(message, "CONNECTOR_CONFIG_VERSION_ROLLBACK")
  }
}

export class ConnectorEnvironmentMismatch extends ConnectorConfigError {
  constructor(message) {
    super(message, "CONNECTOR_ENVIRONMENT_MISMATCH")
  }
}

export class ConnectorIdentityError extends ConnectorError {
  constructor(message) {
    super(message, "CONNECTOR_PRINCIPAL_INVALID")
  }
}

export class ConnectorPolicyDenied extends ConnectorError {
  constructor(message, code = "CONNECTOR_CALL_DENIED") {
    super(message, code)
  }
}

export class ConnectorHardDenied extends ConnectorPolicyDenied {
  constructor(message) {
    super(message, "CONNECTOR_HARD_DENY")
  }
}
