import { ConnectorIdentityError } from "./errors.js"


const RESERVED_HEADERS = Object.freeze([
  "x-agent-user-id", "x-agent-enterprise-user-id", "x-agent-subject",
  "x-agent-roles", "x-agent-scopes", "x-agent-system-id", "x-agent-admin",
  "x-forwarded-user",
  "x-agent-user-assertion",
])

export function createAgentConnectorMiddleware({
  verify,
  protectedPaths = ["/"],
  excludedPaths = ["/health", "/ready", "/oidc/callback"],
}) {
  const protectedPrefixes = protectedPaths.map(cleanPrefix)
  const excludedPrefixes = excludedPaths.map(cleanPrefix)
  return async function agentConnectorMiddleware(request, response, next) {
    const signedAssertion = request.headers["x-agent-user-assertion"]
    for (const header of RESERVED_HEADERS) delete request.headers[header]
    const path = String(request.path ?? request.url ?? "/").split("?", 1)[0]
    const protectedRoute = protectedPrefixes.some((prefix) => matches(path, prefix)) &&
      !excludedPrefixes.some((prefix) => matches(path, prefix))
    if (!protectedRoute) return next()
    const authorization = request.headers.authorization
    const match = typeof authorization === "string" && authorization.match(/^Bearer\s+(.+)$/i)
    const token = typeof signedAssertion === "string" && signedAssertion.trim()
      ? signedAssertion.trim() : match?.[1]?.trim()
    if (!token) return jsonError(response, 401, "CONNECTOR_PRINCIPAL_INVALID", "Authentication required")
    try {
      const principal = await verify(token)
      if (!principal?.subject) throw new ConnectorIdentityError("Principal verifier returned invalid data")
      request.agentPrincipal = principal
      request.headers["x-agent-subject"] = principal.subject
      request.headers["x-agent-user-id"] = principal.agentUserId ?? ""
      request.headers["x-agent-enterprise-user-id"] = principal.enterpriseUserId ?? ""
      request.headers["x-agent-roles"] = JSON.stringify(principal.roles)
      request.headers["x-agent-scopes"] = principal.scopes.join(" ")
      request.headers["x-agent-system-id"] = principal.sourceSystemId ?? ""
      return next()
    } catch (error) {
      if (!(error instanceof ConnectorIdentityError)) throw error
      return jsonError(response, 401, error.code, error.message)
    }
  }
}

function cleanPrefix(value) {
  const normalized = String(value).trim().replace(/\/$/, "") || "/"
  if (!normalized.startsWith("/") || normalized.includes("//") || normalized.includes("\\")) {
    throw new TypeError("Middleware paths must be clean absolute paths")
  }
  return normalized
}

function matches(path, prefix) {
  return prefix === "/" || path === prefix || path.startsWith(`${prefix}/`)
}

function jsonError(response, status, code, message) {
  return response.status(status).json({code, message, retryable: false})
}
