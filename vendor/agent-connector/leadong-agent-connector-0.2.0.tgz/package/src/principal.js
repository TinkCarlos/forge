import { ConnectorIdentityError } from "./errors.js"
import { verifyCompactJws } from "./signing.js"


export function verifyPrincipalToken(token, {
  publicKey,
  issuer,
  audience,
  application,
  environment,
  keyId = null,
  now = Math.floor(Date.now() / 1000),
}) {
  const claims = verifyCompactJws(token, publicKey, {keyId, type: "JWT", identity: true})
  const audiences = Array.isArray(claims.aud) ? claims.aud : [claims.aud]
  if (claims.iss !== issuer || !audiences.includes(audience)) {
    throw new ConnectorIdentityError("Agent principal issuer or audience is invalid")
  }
  if (!claims.sub || !claims.jti || !Number.isInteger(claims.iat) || !Number.isInteger(claims.exp)) {
    throw new ConnectorIdentityError("Agent principal required claims are missing")
  }
  if (claims.exp <= now || claims.iat > now + 60) {
    throw new ConnectorIdentityError("Agent principal token is expired or not yet valid")
  }
  if ((claims.application ?? claims.azp) !== application || claims.environment !== environment) {
    throw new ConnectorIdentityError("Agent principal target does not match this Connector")
  }
  return Object.freeze({
    schemaVersion: "1.0",
    principalType: claims.principal_type ?? "delegated_user",
    subject: claims.sub,
    agentUserId: claims.agent_user_id ?? null,
    enterpriseUserId: claims.userid ?? null,
    clientId: claims.client_id ?? claims.azp ?? null,
    sourceSystemId: claims.source_system_id ?? null,
    username: claims.preferred_username ?? null,
    displayName: claims.name ?? null,
    application,
    environment,
    roles: normalizeRoles(claims.roles ?? []),
    scopes: normalizeScopes(claims.scope ?? claims.scopes ?? []),
    issuedAt: claims.iat,
    expiresAt: claims.exp,
    tokenId: claims.jti,
    traceId: claims.trace_id ?? null,
  })
}

function normalizeRoles(value) {
  if (!Array.isArray(value)) throw new ConnectorIdentityError("Agent roles claim must be a list")
  return value.map((role) => {
    if (typeof role === "string" && role.trim()) return {code: role.trim(), name: role.trim()}
    if (role && typeof role.code === "string" && typeof role.name === "string") {
      return {code: role.code, name: role.name}
    }
    throw new ConnectorIdentityError("Agent roles claim contains an invalid role")
  })
}

function normalizeScopes(value) {
  if (typeof value === "string") return [...new Set(value.split(/\s+/).filter(Boolean))].sort()
  if (Array.isArray(value) && value.every((item) => typeof item === "string")) {
    return [...new Set(value.filter(Boolean))].sort()
  }
  throw new ConnectorIdentityError("Agent scopes claim is invalid")
}
